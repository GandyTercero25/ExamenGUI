import javax.swing.*;

public class BusSimulator {
    public JComponent frame;
}
