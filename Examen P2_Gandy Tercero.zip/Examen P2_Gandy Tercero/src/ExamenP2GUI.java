import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ExamenP2GUI {
    private JFrame frame;
    private JComboBox<Integer> codeComboBox;
    private JComboBox<String> brandComboBox;
    private JComboBox<Integer> cylinderComboBox;
    private JTextField priceTextField;
    private JComboBox<String> insuranceComboBox;
    private JButton addButton;
    private JList<Bus> busList;
    private DefaultListModel<Bus> busListModel;
    private JList<Bus> filteredBusList;
    private DefaultListModel<Bus> filteredBusListModel;
    private JTable priceTable;
    private JTextArea priceTextArea;
    private JComboBox<String> brandComboBoxForGraph;
    private JButton graphButton;



    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                BusSimulator window = new BusSimulator();
                window.frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public ExamenP2GUI() {
        initialize();
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });
        graphButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });
    }

    private void initialize() {
        frame = new JFrame("Bus Simulator");
        frame.setBounds(100, 100, 800, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(new GridLayout(7, 1));

        JPanel panel1 = new JPanel();
        frame.getContentPane().add(panel1);

        codeComboBox = new JComboBox<>();
        for (int i = 1; i <= 10; i++) {
            codeComboBox.addItem(i);
        }
        panel1.add(codeComboBox);

        brandComboBox = new JComboBox<>(new String[]{"MERCEDES", "VOLVO", "SCANIA", "MAN", "IVECO"});
        panel1.add(brandComboBox);

        cylinderComboBox = new JComboBox<>(new Integer[]{5000, 6000, 7000, 8000, 9000});
        panel1.add(cylinderComboBox);

        priceTextField = new JTextField();
        panel1.add(priceTextField);

        insuranceComboBox = new JComboBox<>(new String[]{"INSURED", "NOT INSURED"});
        panel1.add(insuranceComboBox);

        addButton = new JButton("Add Bus");
        panel1.add(addButton);
        addButton.addActionListener(e -> addBus());

        busListModel = new DefaultListModel<>();
        busList = new JList<>(busListModel);
        frame.getContentPane().add(new JScrollPane(busList));

        JPanel panel2 = new JPanel();
        frame.getContentPane().add(panel2);

        brandComboBoxForGraph = new JComboBox<>(new String[]{"MERCEDES", "VOLVO", "SCANIA", "MAN", "IVECO"});
        panel2.add(brandComboBoxForGraph);
        graphButton = new JButton("Graph Buses");
        panel2.add(graphButton);
        graphButton.addActionListener(e -> graphBuses());

        filteredBusListModel = new DefaultListModel<>();
        filteredBusList = new JList<>(filteredBusListModel);
        frame.getContentPane().add(new JScrollPane(filteredBusList));

        String[] header = {"Brand", "Price"};
        priceTable = new JTable(new DefaultTableModel(header, 0));
        frame.getContentPane().add(new JScrollPane(priceTable));

        priceTextArea = new JTextArea();
        frame.getContentPane().add(new JScrollPane(priceTextArea));
    }

    private void graphBuses() {

    }

    private void addBus() {

    }

}